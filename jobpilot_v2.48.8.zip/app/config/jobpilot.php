<?php

return [
    'currency' => env('APP_CURRENCY','USD'),
    'currency_symbol' => env('APP_CURRENCY_SYMBOL','$'),
    'currency_position' => env('APP_CURRENCY_SYMBOL_POSITION','left'),
];
