<?php

namespace App\Http;

use App\Http\Middleware\CheckPlanMiddleware;
use App\Http\Middleware\UserActiveMiddleware;
use App\Http\Middleware\EmailVerifiedMiddleware;
use App\Http\Middleware\EmailVerificationMiddleware;
use Illuminate\Foundation\Http\Kernel as HttpKernel;
use App\Http\Middleware\AutoSetCountryLanguageCurrency;
use App\Http\Middleware\HasPlanMiddleware;

class Kernel extends HttpKernel
{
    /**
     * The application's global HTTP middleware stack.
     *
     * These middleware are run during every request to your application.
     *
     * @var array
     */
    protected $middleware = [
        // \App\Http\Middleware\TrustHosts::class,
        \App\Http\Middleware\TrustProxies::class,
        \Fruitcake\Cors\HandleCors::class,
        \App\Http\Middleware\PreventRequestsDuringMaintenance::class,
        \Illuminate\Foundation\Http\Middleware\ValidatePostSize::class,
        \App\Http\Middleware\TrimStrings::class,
        \Illuminate\Foundation\Http\Middleware\ConvertEmptyStringsToNull::class,
    ];

    /**
     * The application's route middleware groups.
     *
     * @var array
     */
    protected $middlewareGroups = [
        'web' => [
            \App\Http\Middleware\EncryptCookies::class,
            \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
            \Illuminate\Session\Middleware\StartSession::class,
            // \Illuminate\Session\Middleware\AuthenticateSession::class,
            \Illuminate\View\Middleware\ShareErrorsFromSession::class,
            \App\Http\Middleware\VerifyCsrfToken::class,
            \Illuminate\Routing\Middleware\SubstituteBindings::class,
            // \App\Http\Middleware\CheckBloked::class,
            // \App\Http\Middleware\CheckForAppMode::class,

        ],

        'api' => [
            'throttle:api',
            \Illuminate\Routing\Middleware\SubstituteBindings::class,
        ],
    ];

    /**
     * The application's route middleware.
     *
     * These middleware may be assigned to groups or used individually.
     *
     * @var array
     */
    protected $routeMiddleware = [
        'auth' => \App\Http\Middleware\Authenticate::class,
        'auth.basic' => \Illuminate\Auth\Middleware\AuthenticateWithBasicAuth::class,
        'cache.headers' => \Illuminate\Http\Middleware\SetCacheHeaders::class,
        'can' => \Illuminate\Auth\Middleware\Authorize::class,
        'guest' => \App\Http\Middleware\RedirectIfAuthenticated::class,
        'password.confirm' => \Illuminate\Auth\Middleware\RequirePassword::class,
        'signed' => \Illuminate\Routing\Middleware\ValidateSignature::class,
        'throttle' => \Illuminate\Routing\Middleware\ThrottleRequests::class,
        // 'verified' => \Illuminate\Auth\Middleware\EnsureEmailIsVerified::class,
        'verified' => EmailVerifiedMiddleware::class,
        'user_active' => UserActiveMiddleware::class,
        'set_lang' => \Modules\Language\Http\Middleware\SetLangMiddleware::class,
        'role' => \Spatie\Permission\Middlewares\RoleMiddleware::class,
        'permission' => \Spatie\Permission\Middlewares\PermissionMiddleware::class,
        'role_or_permission' => \Spatie\Permission\Middlewares\RoleOrPermissionMiddleware::class,
        'role_check' => \App\Http\Middleware\RoleCheckMiddleware::class,
        'candidate' => \App\Http\Middleware\CandidateMiddleware::class,
        'company' => \App\Http\Middleware\CompanyMiddleware::class,
        'company.profile' => \App\Http\Middleware\CompanyProfileCompletion::class,
        'check_plan' => CheckPlanMiddleware::class,
        'check_mode' => \App\Http\Middleware\CheckForAppMode::class,
        'access_limitation' => \App\Http\Middleware\AccessLimitation::class,
        'auto_set_country_language_currency' => AutoSetCountryLanguageCurrency::class,
        'has_plan' => HasPlanMiddleware::class,
    ];
}
