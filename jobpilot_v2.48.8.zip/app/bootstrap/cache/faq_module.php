<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Faq\\Providers\\FaqServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Faq\\Providers\\FaqServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);