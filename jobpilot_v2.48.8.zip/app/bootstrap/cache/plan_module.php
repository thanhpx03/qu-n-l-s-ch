<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Plan\\Providers\\PlanServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Plan\\Providers\\PlanServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);