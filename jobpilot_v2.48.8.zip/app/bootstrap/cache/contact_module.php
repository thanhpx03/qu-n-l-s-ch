<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Contact\\Providers\\ContactServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Contact\\Providers\\ContactServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);