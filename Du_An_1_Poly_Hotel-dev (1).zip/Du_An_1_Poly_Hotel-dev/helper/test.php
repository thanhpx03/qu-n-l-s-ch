<?php
echo "Đã load";
?>