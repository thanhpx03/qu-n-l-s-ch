<?php require "layout/client/header_client.php" ?>
<?php require "layout/client/home_client.php" ?>
<?php require "layout/client/footer_client.php" ?>


