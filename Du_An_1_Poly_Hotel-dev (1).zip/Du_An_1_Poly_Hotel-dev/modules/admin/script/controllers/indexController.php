<?php

function construct() {}

function uploadPostAction() {
    var_dump($_FILES);
}